/****************************************************************************
** Meta object code from reading C++ file 'game.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../PKUMillionares/game.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'game.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_Game_t {
    uint offsetsAndSizes[154];
    char stringdata0[5];
    char stringdata1[3];
    char stringdata2[1];
    char stringdata3[13];
    char stringdata4[7];
    char stringdata5[2];
    char stringdata6[9];
    char stringdata7[5];
    char stringdata8[25];
    char stringdata9[26];
    char stringdata10[25];
    char stringdata11[26];
    char stringdata12[25];
    char stringdata13[26];
    char stringdata14[25];
    char stringdata15[26];
    char stringdata16[25];
    char stringdata17[26];
    char stringdata18[25];
    char stringdata19[26];
    char stringdata20[25];
    char stringdata21[26];
    char stringdata22[26];
    char stringdata23[25];
    char stringdata24[25];
    char stringdata25[26];
    char stringdata26[25];
    char stringdata27[26];
    char stringdata28[25];
    char stringdata29[26];
    char stringdata30[25];
    char stringdata31[26];
    char stringdata32[25];
    char stringdata33[26];
    char stringdata34[25];
    char stringdata35[26];
    char stringdata36[25];
    char stringdata37[26];
    char stringdata38[25];
    char stringdata39[26];
    char stringdata40[25];
    char stringdata41[26];
    char stringdata42[25];
    char stringdata43[26];
    char stringdata44[25];
    char stringdata45[26];
    char stringdata46[25];
    char stringdata47[26];
    char stringdata48[25];
    char stringdata49[26];
    char stringdata50[25];
    char stringdata51[26];
    char stringdata52[25];
    char stringdata53[26];
    char stringdata54[25];
    char stringdata55[26];
    char stringdata56[25];
    char stringdata57[26];
    char stringdata58[25];
    char stringdata59[26];
    char stringdata60[25];
    char stringdata61[26];
    char stringdata62[25];
    char stringdata63[26];
    char stringdata64[25];
    char stringdata65[26];
    char stringdata66[25];
    char stringdata67[26];
    char stringdata68[25];
    char stringdata69[26];
    char stringdata70[25];
    char stringdata71[26];
    char stringdata72[18];
    char stringdata73[22];
    char stringdata74[19];
    char stringdata75[19];
    char stringdata76[19];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_Game_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_Game_t qt_meta_stringdata_Game = {
    {
        QT_MOC_LITERAL(0, 4),  // "Game"
        QT_MOC_LITERAL(5, 2),  // "Do"
        QT_MOC_LITERAL(8, 0),  // ""
        QT_MOC_LITERAL(9, 12),  // "QPushButton*"
        QT_MOC_LITERAL(22, 6),  // "button"
        QT_MOC_LITERAL(29, 1),  // "u"
        QT_MOC_LITERAL(31, 8),  // "pic_root"
        QT_MOC_LITERAL(40, 4),  // "Undo"
        QT_MOC_LITERAL(45, 24),  // "on_pushButton_00_pressed"
        QT_MOC_LITERAL(70, 25),  // "on_pushButton_00_released"
        QT_MOC_LITERAL(96, 24),  // "on_pushButton_01_pressed"
        QT_MOC_LITERAL(121, 25),  // "on_pushButton_01_released"
        QT_MOC_LITERAL(147, 24),  // "on_pushButton_02_pressed"
        QT_MOC_LITERAL(172, 25),  // "on_pushButton_02_released"
        QT_MOC_LITERAL(198, 24),  // "on_pushButton_03_pressed"
        QT_MOC_LITERAL(223, 25),  // "on_pushButton_03_released"
        QT_MOC_LITERAL(249, 24),  // "on_pushButton_04_pressed"
        QT_MOC_LITERAL(274, 25),  // "on_pushButton_04_released"
        QT_MOC_LITERAL(300, 24),  // "on_pushButton_05_pressed"
        QT_MOC_LITERAL(325, 25),  // "on_pushButton_05_released"
        QT_MOC_LITERAL(351, 24),  // "on_pushButton_06_pressed"
        QT_MOC_LITERAL(376, 25),  // "on_pushButton_06_released"
        QT_MOC_LITERAL(402, 25),  // "on_pushButton_07_released"
        QT_MOC_LITERAL(428, 24),  // "on_pushButton_07_pressed"
        QT_MOC_LITERAL(453, 24),  // "on_pushButton_08_pressed"
        QT_MOC_LITERAL(478, 25),  // "on_pushButton_08_released"
        QT_MOC_LITERAL(504, 24),  // "on_pushButton_09_pressed"
        QT_MOC_LITERAL(529, 25),  // "on_pushButton_09_released"
        QT_MOC_LITERAL(555, 24),  // "on_pushButton_10_pressed"
        QT_MOC_LITERAL(580, 25),  // "on_pushButton_10_released"
        QT_MOC_LITERAL(606, 24),  // "on_pushButton_11_pressed"
        QT_MOC_LITERAL(631, 25),  // "on_pushButton_11_released"
        QT_MOC_LITERAL(657, 24),  // "on_pushButton_12_pressed"
        QT_MOC_LITERAL(682, 25),  // "on_pushButton_12_released"
        QT_MOC_LITERAL(708, 24),  // "on_pushButton_13_pressed"
        QT_MOC_LITERAL(733, 25),  // "on_pushButton_13_released"
        QT_MOC_LITERAL(759, 24),  // "on_pushButton_14_pressed"
        QT_MOC_LITERAL(784, 25),  // "on_pushButton_14_released"
        QT_MOC_LITERAL(810, 24),  // "on_pushButton_15_pressed"
        QT_MOC_LITERAL(835, 25),  // "on_pushButton_15_released"
        QT_MOC_LITERAL(861, 24),  // "on_pushButton_16_pressed"
        QT_MOC_LITERAL(886, 25),  // "on_pushButton_16_released"
        QT_MOC_LITERAL(912, 24),  // "on_pushButton_17_pressed"
        QT_MOC_LITERAL(937, 25),  // "on_pushButton_17_released"
        QT_MOC_LITERAL(963, 24),  // "on_pushButton_18_pressed"
        QT_MOC_LITERAL(988, 25),  // "on_pushButton_18_released"
        QT_MOC_LITERAL(1014, 24),  // "on_pushButton_19_pressed"
        QT_MOC_LITERAL(1039, 25),  // "on_pushButton_19_released"
        QT_MOC_LITERAL(1065, 24),  // "on_pushButton_20_pressed"
        QT_MOC_LITERAL(1090, 25),  // "on_pushButton_20_released"
        QT_MOC_LITERAL(1116, 24),  // "on_pushButton_21_pressed"
        QT_MOC_LITERAL(1141, 25),  // "on_pushButton_21_released"
        QT_MOC_LITERAL(1167, 24),  // "on_pushButton_22_pressed"
        QT_MOC_LITERAL(1192, 25),  // "on_pushButton_22_released"
        QT_MOC_LITERAL(1218, 24),  // "on_pushButton_23_pressed"
        QT_MOC_LITERAL(1243, 25),  // "on_pushButton_23_released"
        QT_MOC_LITERAL(1269, 24),  // "on_pushButton_24_pressed"
        QT_MOC_LITERAL(1294, 25),  // "on_pushButton_24_released"
        QT_MOC_LITERAL(1320, 24),  // "on_pushButton_25_pressed"
        QT_MOC_LITERAL(1345, 25),  // "on_pushButton_25_released"
        QT_MOC_LITERAL(1371, 24),  // "on_pushButton_26_pressed"
        QT_MOC_LITERAL(1396, 25),  // "on_pushButton_26_released"
        QT_MOC_LITERAL(1422, 24),  // "on_pushButton_27_pressed"
        QT_MOC_LITERAL(1447, 25),  // "on_pushButton_27_released"
        QT_MOC_LITERAL(1473, 24),  // "on_pushButton_28_pressed"
        QT_MOC_LITERAL(1498, 25),  // "on_pushButton_28_released"
        QT_MOC_LITERAL(1524, 24),  // "on_pushButton_29_pressed"
        QT_MOC_LITERAL(1549, 25),  // "on_pushButton_29_released"
        QT_MOC_LITERAL(1575, 24),  // "on_pushButton_30_pressed"
        QT_MOC_LITERAL(1600, 25),  // "on_pushButton_30_released"
        QT_MOC_LITERAL(1626, 24),  // "on_pushButton_31_pressed"
        QT_MOC_LITERAL(1651, 25),  // "on_pushButton_31_released"
        QT_MOC_LITERAL(1677, 17),  // "on_Return_clicked"
        QT_MOC_LITERAL(1695, 21),  // "on_pushButton_clicked"
        QT_MOC_LITERAL(1717, 18),  // "on_choice1_clicked"
        QT_MOC_LITERAL(1736, 18),  // "on_choice2_clicked"
        QT_MOC_LITERAL(1755, 18)   // "on_choice3_clicked"
    },
    "Game",
    "Do",
    "",
    "QPushButton*",
    "button",
    "u",
    "pic_root",
    "Undo",
    "on_pushButton_00_pressed",
    "on_pushButton_00_released",
    "on_pushButton_01_pressed",
    "on_pushButton_01_released",
    "on_pushButton_02_pressed",
    "on_pushButton_02_released",
    "on_pushButton_03_pressed",
    "on_pushButton_03_released",
    "on_pushButton_04_pressed",
    "on_pushButton_04_released",
    "on_pushButton_05_pressed",
    "on_pushButton_05_released",
    "on_pushButton_06_pressed",
    "on_pushButton_06_released",
    "on_pushButton_07_released",
    "on_pushButton_07_pressed",
    "on_pushButton_08_pressed",
    "on_pushButton_08_released",
    "on_pushButton_09_pressed",
    "on_pushButton_09_released",
    "on_pushButton_10_pressed",
    "on_pushButton_10_released",
    "on_pushButton_11_pressed",
    "on_pushButton_11_released",
    "on_pushButton_12_pressed",
    "on_pushButton_12_released",
    "on_pushButton_13_pressed",
    "on_pushButton_13_released",
    "on_pushButton_14_pressed",
    "on_pushButton_14_released",
    "on_pushButton_15_pressed",
    "on_pushButton_15_released",
    "on_pushButton_16_pressed",
    "on_pushButton_16_released",
    "on_pushButton_17_pressed",
    "on_pushButton_17_released",
    "on_pushButton_18_pressed",
    "on_pushButton_18_released",
    "on_pushButton_19_pressed",
    "on_pushButton_19_released",
    "on_pushButton_20_pressed",
    "on_pushButton_20_released",
    "on_pushButton_21_pressed",
    "on_pushButton_21_released",
    "on_pushButton_22_pressed",
    "on_pushButton_22_released",
    "on_pushButton_23_pressed",
    "on_pushButton_23_released",
    "on_pushButton_24_pressed",
    "on_pushButton_24_released",
    "on_pushButton_25_pressed",
    "on_pushButton_25_released",
    "on_pushButton_26_pressed",
    "on_pushButton_26_released",
    "on_pushButton_27_pressed",
    "on_pushButton_27_released",
    "on_pushButton_28_pressed",
    "on_pushButton_28_released",
    "on_pushButton_29_pressed",
    "on_pushButton_29_released",
    "on_pushButton_30_pressed",
    "on_pushButton_30_released",
    "on_pushButton_31_pressed",
    "on_pushButton_31_released",
    "on_Return_clicked",
    "on_pushButton_clicked",
    "on_choice1_clicked",
    "on_choice2_clicked",
    "on_choice3_clicked"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_Game[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      71,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    3,  440,    2, 0x08,    1 /* Private */,
       7,    1,  447,    2, 0x08,    5 /* Private */,
       8,    0,  450,    2, 0x08,    7 /* Private */,
       9,    0,  451,    2, 0x08,    8 /* Private */,
      10,    0,  452,    2, 0x08,    9 /* Private */,
      11,    0,  453,    2, 0x08,   10 /* Private */,
      12,    0,  454,    2, 0x08,   11 /* Private */,
      13,    0,  455,    2, 0x08,   12 /* Private */,
      14,    0,  456,    2, 0x08,   13 /* Private */,
      15,    0,  457,    2, 0x08,   14 /* Private */,
      16,    0,  458,    2, 0x08,   15 /* Private */,
      17,    0,  459,    2, 0x08,   16 /* Private */,
      18,    0,  460,    2, 0x08,   17 /* Private */,
      19,    0,  461,    2, 0x08,   18 /* Private */,
      20,    0,  462,    2, 0x08,   19 /* Private */,
      21,    0,  463,    2, 0x08,   20 /* Private */,
      22,    0,  464,    2, 0x08,   21 /* Private */,
      23,    0,  465,    2, 0x08,   22 /* Private */,
      24,    0,  466,    2, 0x08,   23 /* Private */,
      25,    0,  467,    2, 0x08,   24 /* Private */,
      26,    0,  468,    2, 0x08,   25 /* Private */,
      27,    0,  469,    2, 0x08,   26 /* Private */,
      28,    0,  470,    2, 0x08,   27 /* Private */,
      29,    0,  471,    2, 0x08,   28 /* Private */,
      30,    0,  472,    2, 0x08,   29 /* Private */,
      31,    0,  473,    2, 0x08,   30 /* Private */,
      32,    0,  474,    2, 0x08,   31 /* Private */,
      33,    0,  475,    2, 0x08,   32 /* Private */,
      34,    0,  476,    2, 0x08,   33 /* Private */,
      35,    0,  477,    2, 0x08,   34 /* Private */,
      36,    0,  478,    2, 0x08,   35 /* Private */,
      37,    0,  479,    2, 0x08,   36 /* Private */,
      38,    0,  480,    2, 0x08,   37 /* Private */,
      39,    0,  481,    2, 0x08,   38 /* Private */,
      40,    0,  482,    2, 0x08,   39 /* Private */,
      41,    0,  483,    2, 0x08,   40 /* Private */,
      42,    0,  484,    2, 0x08,   41 /* Private */,
      43,    0,  485,    2, 0x08,   42 /* Private */,
      44,    0,  486,    2, 0x08,   43 /* Private */,
      45,    0,  487,    2, 0x08,   44 /* Private */,
      46,    0,  488,    2, 0x08,   45 /* Private */,
      47,    0,  489,    2, 0x08,   46 /* Private */,
      48,    0,  490,    2, 0x08,   47 /* Private */,
      49,    0,  491,    2, 0x08,   48 /* Private */,
      50,    0,  492,    2, 0x08,   49 /* Private */,
      51,    0,  493,    2, 0x08,   50 /* Private */,
      52,    0,  494,    2, 0x08,   51 /* Private */,
      53,    0,  495,    2, 0x08,   52 /* Private */,
      54,    0,  496,    2, 0x08,   53 /* Private */,
      55,    0,  497,    2, 0x08,   54 /* Private */,
      56,    0,  498,    2, 0x08,   55 /* Private */,
      57,    0,  499,    2, 0x08,   56 /* Private */,
      58,    0,  500,    2, 0x08,   57 /* Private */,
      59,    0,  501,    2, 0x08,   58 /* Private */,
      60,    0,  502,    2, 0x08,   59 /* Private */,
      61,    0,  503,    2, 0x08,   60 /* Private */,
      62,    0,  504,    2, 0x08,   61 /* Private */,
      63,    0,  505,    2, 0x08,   62 /* Private */,
      64,    0,  506,    2, 0x08,   63 /* Private */,
      65,    0,  507,    2, 0x08,   64 /* Private */,
      66,    0,  508,    2, 0x08,   65 /* Private */,
      67,    0,  509,    2, 0x08,   66 /* Private */,
      68,    0,  510,    2, 0x08,   67 /* Private */,
      69,    0,  511,    2, 0x08,   68 /* Private */,
      70,    0,  512,    2, 0x08,   69 /* Private */,
      71,    0,  513,    2, 0x08,   70 /* Private */,
      72,    0,  514,    2, 0x08,   71 /* Private */,
      73,    0,  515,    2, 0x08,   72 /* Private */,
      74,    0,  516,    2, 0x08,   73 /* Private */,
      75,    0,  517,    2, 0x08,   74 /* Private */,
      76,    0,  518,    2, 0x08,   75 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3, QMetaType::Int, QMetaType::QString,    4,    5,    6,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject Game::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_Game.offsetsAndSizes,
    qt_meta_data_Game,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_Game_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Game, std::true_type>,
        // method 'Do'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPushButton *, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString, std::false_type>,
        // method 'Undo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_pushButton_00_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_00_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_01_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_01_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_02_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_02_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_03_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_03_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_04_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_04_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_05_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_05_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_06_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_06_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_07_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_07_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_08_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_08_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_09_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_09_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_10_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_10_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_11_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_11_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_12_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_12_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_13_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_13_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_14_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_14_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_15_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_15_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_16_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_16_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_17_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_17_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_18_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_18_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_19_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_19_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_20_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_20_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_21_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_21_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_22_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_22_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_23_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_23_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_24_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_24_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_25_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_25_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_26_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_26_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_27_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_27_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_28_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_28_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_29_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_29_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_30_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_30_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_31_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_31_released'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Return_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_choice1_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_choice2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_choice3_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void Game::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Game *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->Do((*reinterpret_cast< std::add_pointer_t<QPushButton*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3]))); break;
        case 1: _t->Undo((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->on_pushButton_00_pressed(); break;
        case 3: _t->on_pushButton_00_released(); break;
        case 4: _t->on_pushButton_01_pressed(); break;
        case 5: _t->on_pushButton_01_released(); break;
        case 6: _t->on_pushButton_02_pressed(); break;
        case 7: _t->on_pushButton_02_released(); break;
        case 8: _t->on_pushButton_03_pressed(); break;
        case 9: _t->on_pushButton_03_released(); break;
        case 10: _t->on_pushButton_04_pressed(); break;
        case 11: _t->on_pushButton_04_released(); break;
        case 12: _t->on_pushButton_05_pressed(); break;
        case 13: _t->on_pushButton_05_released(); break;
        case 14: _t->on_pushButton_06_pressed(); break;
        case 15: _t->on_pushButton_06_released(); break;
        case 16: _t->on_pushButton_07_released(); break;
        case 17: _t->on_pushButton_07_pressed(); break;
        case 18: _t->on_pushButton_08_pressed(); break;
        case 19: _t->on_pushButton_08_released(); break;
        case 20: _t->on_pushButton_09_pressed(); break;
        case 21: _t->on_pushButton_09_released(); break;
        case 22: _t->on_pushButton_10_pressed(); break;
        case 23: _t->on_pushButton_10_released(); break;
        case 24: _t->on_pushButton_11_pressed(); break;
        case 25: _t->on_pushButton_11_released(); break;
        case 26: _t->on_pushButton_12_pressed(); break;
        case 27: _t->on_pushButton_12_released(); break;
        case 28: _t->on_pushButton_13_pressed(); break;
        case 29: _t->on_pushButton_13_released(); break;
        case 30: _t->on_pushButton_14_pressed(); break;
        case 31: _t->on_pushButton_14_released(); break;
        case 32: _t->on_pushButton_15_pressed(); break;
        case 33: _t->on_pushButton_15_released(); break;
        case 34: _t->on_pushButton_16_pressed(); break;
        case 35: _t->on_pushButton_16_released(); break;
        case 36: _t->on_pushButton_17_pressed(); break;
        case 37: _t->on_pushButton_17_released(); break;
        case 38: _t->on_pushButton_18_pressed(); break;
        case 39: _t->on_pushButton_18_released(); break;
        case 40: _t->on_pushButton_19_pressed(); break;
        case 41: _t->on_pushButton_19_released(); break;
        case 42: _t->on_pushButton_20_pressed(); break;
        case 43: _t->on_pushButton_20_released(); break;
        case 44: _t->on_pushButton_21_pressed(); break;
        case 45: _t->on_pushButton_21_released(); break;
        case 46: _t->on_pushButton_22_pressed(); break;
        case 47: _t->on_pushButton_22_released(); break;
        case 48: _t->on_pushButton_23_pressed(); break;
        case 49: _t->on_pushButton_23_released(); break;
        case 50: _t->on_pushButton_24_pressed(); break;
        case 51: _t->on_pushButton_24_released(); break;
        case 52: _t->on_pushButton_25_pressed(); break;
        case 53: _t->on_pushButton_25_released(); break;
        case 54: _t->on_pushButton_26_pressed(); break;
        case 55: _t->on_pushButton_26_released(); break;
        case 56: _t->on_pushButton_27_pressed(); break;
        case 57: _t->on_pushButton_27_released(); break;
        case 58: _t->on_pushButton_28_pressed(); break;
        case 59: _t->on_pushButton_28_released(); break;
        case 60: _t->on_pushButton_29_pressed(); break;
        case 61: _t->on_pushButton_29_released(); break;
        case 62: _t->on_pushButton_30_pressed(); break;
        case 63: _t->on_pushButton_30_released(); break;
        case 64: _t->on_pushButton_31_pressed(); break;
        case 65: _t->on_pushButton_31_released(); break;
        case 66: _t->on_Return_clicked(); break;
        case 67: _t->on_pushButton_clicked(); break;
        case 68: _t->on_choice1_clicked(); break;
        case 69: _t->on_choice2_clicked(); break;
        case 70: _t->on_choice3_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QPushButton* >(); break;
            }
            break;
        }
    }
}

const QMetaObject *Game::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Game::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Game.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int Game::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 71)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 71;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 71)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 71;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
