/********************************************************************************
** Form generated from reading UI file 'result.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESULT_H
#define UI_RESULT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Result
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QPushButton *pushButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Result)
    {
        if (Result->objectName().isEmpty())
            Result->setObjectName("Result");
        Result->resize(800, 600);
        centralwidget = new QWidget(Result);
        centralwidget->setObjectName("centralwidget");
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(230, 120, 411, 331));
        QPalette palette;
        QBrush brush(QColor(195, 30, 8, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        label->setPalette(palette);
        label->setStyleSheet(QString::fromUtf8("font: 20pt \"Showcard Gothic\";"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(720, 10, 71, 61));
        pushButton->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe Print\";"));
        Result->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Result);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 800, 25));
        Result->setMenuBar(menubar);
        statusbar = new QStatusBar(Result);
        statusbar->setObjectName("statusbar");
        Result->setStatusBar(statusbar);

        retranslateUi(Result);

        QMetaObject::connectSlotsByName(Result);
    } // setupUi

    void retranslateUi(QMainWindow *Result)
    {
        Result->setWindowTitle(QCoreApplication::translate("Result", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("Result", "TextLabel", nullptr));
        pushButton->setText(QCoreApplication::translate("Result", "Return", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Result: public Ui_Result {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESULT_H
