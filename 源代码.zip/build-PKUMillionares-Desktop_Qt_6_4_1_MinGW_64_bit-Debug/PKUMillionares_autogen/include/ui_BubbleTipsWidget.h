/********************************************************************************
** Form generated from reading UI file 'bubbletipswidget.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BUBBLETIPSWIDGET_H
#define UI_BUBBLETIPSWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_BubbleTipsWidget
{
public:
    QWidget *widget;
    QLabel *label;

    void setupUi(QWidget *BubbleTipsWidget)
    {
        if (BubbleTipsWidget->objectName().isEmpty())
            BubbleTipsWidget->setObjectName("BubbleTipsWidget");
        BubbleTipsWidget->resize(490, 452);
        widget = new QWidget(BubbleTipsWidget);
        widget->setObjectName("widget");
        widget->setGeometry(QRect(15, 15, 460, 291));
        label = new QLabel(BubbleTipsWidget);
        label->setObjectName("label");
        label->setGeometry(QRect(70, 320, 321, 111));
        label->setStyleSheet(QString::fromUtf8("font: 700 10pt \"Terminal\";"));
        label->setAlignment(Qt::AlignCenter);

        retranslateUi(BubbleTipsWidget);

        QMetaObject::connectSlotsByName(BubbleTipsWidget);
    } // setupUi

    void retranslateUi(QWidget *BubbleTipsWidget)
    {
        BubbleTipsWidget->setWindowTitle(QCoreApplication::translate("BubbleTipsWidget", "Form", nullptr));
        label->setText(QCoreApplication::translate("BubbleTipsWidget", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class BubbleTipsWidget: public Ui_BubbleTipsWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BUBBLETIPSWIDGET_H
