/********************************************************************************
** Form generated from reading UI file 'hello.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HELLO_H
#define UI_HELLO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Hello
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton1;
    QPushButton *pushButton2;
    QLineEdit *lineEdit;
    QListWidget *listWidget;
    QPushButton *pushButton;
    QLabel *register_instruction;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Hello)
    {
        if (Hello->objectName().isEmpty())
            Hello->setObjectName("Hello");
        Hello->resize(800, 600);
        centralwidget = new QWidget(Hello);
        centralwidget->setObjectName("centralwidget");
        pushButton1 = new QPushButton(centralwidget);
        pushButton1->setObjectName("pushButton1");
        pushButton1->setGeometry(QRect(260, 330, 111, 61));
        pushButton1->setStyleSheet(QString::fromUtf8("background-color: rgba(255, 255, 255, 0);\n"
"font: 700 16pt \"Segoe Script\";"));
        pushButton2 = new QPushButton(centralwidget);
        pushButton2->setObjectName("pushButton2");
        pushButton2->setGeometry(QRect(420, 330, 111, 61));
        pushButton2->setStyleSheet(QString::fromUtf8("background-color: rgba(255, 255, 255, 0);\n"
"font: 700 16pt \"Segoe Script\";"));
        lineEdit = new QLineEdit(centralwidget);
        lineEdit->setObjectName("lineEdit");
        lineEdit->setGeometry(QRect(260, 270, 261, 41));
        lineEdit->setStyleSheet(QString::fromUtf8("font: 10pt \"Segoe Print\";"));
        listWidget = new QListWidget(centralwidget);
        listWidget->setObjectName("listWidget");
        listWidget->setGeometry(QRect(290, 150, 201, 161));
        listWidget->setStyleSheet(QString::fromUtf8("background-color: rgba(255, 255, 255, 66);\n"
"font: 10pt \"Segoe Print\";"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(730, 10, 61, 61));
        pushButton->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe Print\";"));
        register_instruction = new QLabel(centralwidget);
        register_instruction->setObjectName("register_instruction");
        register_instruction->setGeometry(QRect(250, 170, 281, 71));
        register_instruction->setStyleSheet(QString::fromUtf8("font: 10pt \"Segoe Print\";\n"
""));
        register_instruction->setAlignment(Qt::AlignCenter);
        Hello->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Hello);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 800, 25));
        Hello->setMenuBar(menubar);
        statusbar = new QStatusBar(Hello);
        statusbar->setObjectName("statusbar");
        Hello->setStatusBar(statusbar);

        retranslateUi(Hello);

        QMetaObject::connectSlotsByName(Hello);
    } // setupUi

    void retranslateUi(QMainWindow *Hello)
    {
        Hello->setWindowTitle(QCoreApplication::translate("Hello", "MainWindow", nullptr));
        pushButton1->setText(QCoreApplication::translate("Hello", "PushButton", nullptr));
        pushButton2->setText(QCoreApplication::translate("Hello", "PushButton", nullptr));
        pushButton->setText(QCoreApplication::translate("Hello", "Return", nullptr));
        register_instruction->setText(QCoreApplication::translate("Hello", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Hello: public Ui_Hello {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HELLO_H
