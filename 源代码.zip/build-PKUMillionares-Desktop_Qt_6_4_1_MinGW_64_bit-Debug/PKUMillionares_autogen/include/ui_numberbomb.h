/********************************************************************************
** Form generated from reading UI file 'numberbomb.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NUMBERBOMB_H
#define UI_NUMBERBOMB_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_NumberBomb
{
public:
    QWidget *centralwidget;
    QLineEdit *lineEdit;
    QPushButton *pushButton;
    QLabel *label;
    QLabel *result_return;
    QLCDNumber *time_lcd;
    QLabel *label_3;
    QLabel *label_4;
    QLCDNumber *num_lcd;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *NumberBomb)
    {
        if (NumberBomb->objectName().isEmpty())
            NumberBomb->setObjectName("NumberBomb");
        NumberBomb->resize(800, 600);
        centralwidget = new QWidget(NumberBomb);
        centralwidget->setObjectName("centralwidget");
        lineEdit = new QLineEdit(centralwidget);
        lineEdit->setObjectName("lineEdit");
        lineEdit->setGeometry(QRect(320, 250, 171, 61));
        QFont font;
        font.setPointSize(16);
        lineEdit->setFont(font);
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(730, 10, 61, 61));
        pushButton->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe Print\";\n"
"background-color: rgba(200, 167, 238, 220);"));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(310, 30, 111, 31));
        result_return = new QLabel(centralwidget);
        result_return->setObjectName("result_return");
        result_return->setGeometry(QRect(320, 330, 241, 71));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("\345\215\216\346\226\207\350\241\214\346\245\267")});
        font1.setPointSize(18);
        font1.setBold(false);
        result_return->setFont(font1);
        result_return->setLayoutDirection(Qt::LeftToRight);
        time_lcd = new QLCDNumber(centralwidget);
        time_lcd->setObjectName("time_lcd");
        time_lcd->setGeometry(QRect(270, 430, 81, 41));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Mistral")});
        font2.setPointSize(16);
        time_lcd->setFont(font2);
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(10, 0, 61, 31));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(10, 30, 61, 31));
        num_lcd = new QLCDNumber(centralwidget);
        num_lcd->setObjectName("num_lcd");
        num_lcd->setGeometry(QRect(270, 510, 81, 41));
        num_lcd->setFont(font);
        NumberBomb->setCentralWidget(centralwidget);
        menubar = new QMenuBar(NumberBomb);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 800, 25));
        NumberBomb->setMenuBar(menubar);
        statusbar = new QStatusBar(NumberBomb);
        statusbar->setObjectName("statusbar");
        NumberBomb->setStatusBar(statusbar);

        retranslateUi(NumberBomb);

        QMetaObject::connectSlotsByName(NumberBomb);
    } // setupUi

    void retranslateUi(QMainWindow *NumberBomb)
    {
        NumberBomb->setWindowTitle(QCoreApplication::translate("NumberBomb", "MainWindow", nullptr));
        lineEdit->setText(QCoreApplication::translate("NumberBomb", "10", nullptr));
        pushButton->setText(QCoreApplication::translate("NumberBomb", "Return", nullptr));
        label->setText(QString());
        result_return->setText(QCoreApplication::translate("NumberBomb", "\345\244\252\345\244\247\344\272\206", nullptr));
        label_3->setText(QString());
        label_4->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class NumberBomb: public Ui_NumberBomb {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NUMBERBOMB_H
