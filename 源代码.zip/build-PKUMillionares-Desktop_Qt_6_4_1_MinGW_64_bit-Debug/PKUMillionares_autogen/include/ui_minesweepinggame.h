/********************************************************************************
** Form generated from reading UI file 'minesweepinggame.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MINESWEEPINGGAME_H
#define UI_MINESWEEPINGGAME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MineSweepingGame
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton;
    QLCDNumber *lcdNumber;
    QLabel *label;
    QLabel *label_2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MineSweepingGame)
    {
        if (MineSweepingGame->objectName().isEmpty())
            MineSweepingGame->setObjectName("MineSweepingGame");
        MineSweepingGame->resize(800, 600);
        centralwidget = new QWidget(MineSweepingGame);
        centralwidget->setObjectName("centralwidget");
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(719, 10, 61, 61));
        pushButton->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe Print\";\n"
"background-color: rgba(210, 175, 250, 200);"));
        lcdNumber = new QLCDNumber(centralwidget);
        lcdNumber->setObjectName("lcdNumber");
        lcdNumber->setGeometry(QRect(680, 500, 81, 31));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(650, 450, 141, 41));
        QFont font;
        font.setFamilies({QString::fromUtf8("Monotype Corsiva")});
        font.setPointSize(22);
        font.setItalic(true);
        label->setFont(font);
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(560, 220, 181, 121));
        QPalette palette;
        QBrush brush(QColor(253, 93, 93, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        QBrush brush1(QColor(120, 120, 120, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        label_2->setPalette(palette);
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Snap ITC")});
        font1.setPointSize(20);
        font1.setBold(false);
        label_2->setFont(font1);
        MineSweepingGame->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MineSweepingGame);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 800, 23));
        MineSweepingGame->setMenuBar(menubar);
        statusbar = new QStatusBar(MineSweepingGame);
        statusbar->setObjectName("statusbar");
        MineSweepingGame->setStatusBar(statusbar);

        retranslateUi(MineSweepingGame);

        QMetaObject::connectSlotsByName(MineSweepingGame);
    } // setupUi

    void retranslateUi(QMainWindow *MineSweepingGame)
    {
        MineSweepingGame->setWindowTitle(QCoreApplication::translate("MineSweepingGame", "MainWindow", nullptr));
        pushButton->setText(QCoreApplication::translate("MineSweepingGame", "Return", nullptr));
        label->setText(QCoreApplication::translate("MineSweepingGame", "Mine Left", nullptr));
        label_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MineSweepingGame: public Ui_MineSweepingGame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MINESWEEPINGGAME_H
