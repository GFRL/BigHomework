/********************************************************************************
** Form generated from reading UI file 'game.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GAME_H
#define UI_GAME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Game
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton_01;
    QPushButton *pushButton_02;
    QPushButton *pushButton_03;
    QPushButton *pushButton_04;
    QPushButton *pushButton_05;
    QPushButton *pushButton_06;
    QPushButton *pushButton_07;
    QPushButton *pushButton_08;
    QPushButton *pushButton_09;
    QPushButton *pushButton_10;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QPushButton *pushButton_13;
    QPushButton *pushButton_14;
    QPushButton *pushButton_15;
    QPushButton *pushButton_16;
    QPushButton *pushButton_17;
    QPushButton *pushButton_18;
    QPushButton *pushButton_19;
    QPushButton *pushButton_20;
    QPushButton *pushButton_21;
    QPushButton *pushButton_22;
    QPushButton *pushButton_23;
    QPushButton *pushButton_24;
    QPushButton *pushButton_25;
    QPushButton *pushButton_26;
    QPushButton *pushButton_27;
    QPushButton *pushButton_28;
    QPushButton *pushButton_29;
    QPushButton *pushButton_30;
    QPushButton *pushButton_31;
    QPushButton *pushButton_00;
    QLabel *label_0;
    QLabel *label_1;
    QPushButton *Return;
    QPushButton *pushButton;
    QWidget *widget;
    QLabel *label;
    QPushButton *choice1;
    QPushButton *choice2;
    QPushButton *choice3;
    QLabel *label_detail;
    QPushButton *player__1;
    QPushButton *player__2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Game)
    {
        if (Game->objectName().isEmpty())
            Game->setObjectName("Game");
        Game->resize(1200, 650);
        centralwidget = new QWidget(Game);
        centralwidget->setObjectName("centralwidget");
        pushButton_01 = new QPushButton(centralwidget);
        pushButton_01->setObjectName("pushButton_01");
        pushButton_01->setGeometry(QRect(250, 40, 60, 60));
        QPalette palette;
        QBrush brush(QColor(246, 242, 164, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush);
        palette.setBrush(QPalette::Active, QPalette::Light, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        palette.setBrush(QPalette::Active, QPalette::Window, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush);
        pushButton_01->setPalette(palette);
        pushButton_01->setStyleSheet(QString::fromUtf8("background-color: rgb(246, 242,164);"));
        pushButton_02 = new QPushButton(centralwidget);
        pushButton_02->setObjectName("pushButton_02");
        pushButton_02->setGeometry(QRect(310, 40, 60, 60));
        QFont font;
        font.setPointSize(8);
        pushButton_02->setFont(font);
        pushButton_02->setStyleSheet(QString::fromUtf8("background-color: rgb(184, 213, 247);"));
        pushButton_03 = new QPushButton(centralwidget);
        pushButton_03->setObjectName("pushButton_03");
        pushButton_03->setGeometry(QRect(370, 40, 60, 60));
        pushButton_03->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 0);"));
        pushButton_04 = new QPushButton(centralwidget);
        pushButton_04->setObjectName("pushButton_04");
        pushButton_04->setGeometry(QRect(430, 40, 60, 60));
        pushButton_04->setStyleSheet(QString::fromUtf8("background-color: rgb(184, 213, 247);"));
        pushButton_05 = new QPushButton(centralwidget);
        pushButton_05->setObjectName("pushButton_05");
        pushButton_05->setGeometry(QRect(490, 40, 60, 60));
        pushButton_05->setFont(font);
        pushButton_05->setStyleSheet(QString::fromUtf8("background-color: rgb(246, 242, 164);"));
        pushButton_06 = new QPushButton(centralwidget);
        pushButton_06->setObjectName("pushButton_06");
        pushButton_06->setGeometry(QRect(550, 40, 60, 60));
        pushButton_06->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(135, 135, 135);"));
        pushButton_07 = new QPushButton(centralwidget);
        pushButton_07->setObjectName("pushButton_07");
        pushButton_07->setGeometry(QRect(610, 40, 60, 60));
        pushButton_07->setStyleSheet(QString::fromUtf8("background-color: rgb(246, 242, 164);"));
        pushButton_08 = new QPushButton(centralwidget);
        pushButton_08->setObjectName("pushButton_08");
        pushButton_08->setGeometry(QRect(670, 40, 60, 60));
        pushButton_08->setStyleSheet(QString::fromUtf8("background-color: rgb(88, 217, 9);"));
        pushButton_09 = new QPushButton(centralwidget);
        pushButton_09->setObjectName("pushButton_09");
        pushButton_09->setGeometry(QRect(670, 100, 60, 60));
        pushButton_09->setStyleSheet(QString::fromUtf8("background-color: rgb(189, 251, 193);"));
        pushButton_10 = new QPushButton(centralwidget);
        pushButton_10->setObjectName("pushButton_10");
        pushButton_10->setGeometry(QRect(670, 160, 60, 60));
        pushButton_10->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 0);"));
        pushButton_11 = new QPushButton(centralwidget);
        pushButton_11->setObjectName("pushButton_11");
        pushButton_11->setGeometry(QRect(670, 220, 60, 60));
        pushButton_11->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(10, 10, 10);"));
        pushButton_12 = new QPushButton(centralwidget);
        pushButton_12->setObjectName("pushButton_12");
        pushButton_12->setGeometry(QRect(670, 280, 60, 60));
        pushButton_12->setStyleSheet(QString::fromUtf8("background-color: rgb(184, 213, 247);\n"
""));
        pushButton_13 = new QPushButton(centralwidget);
        pushButton_13->setObjectName("pushButton_13");
        pushButton_13->setGeometry(QRect(670, 340, 60, 60));
        pushButton_13->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"background-color: rgb(135, 135, 135);"));
        pushButton_14 = new QPushButton(centralwidget);
        pushButton_14->setObjectName("pushButton_14");
        pushButton_14->setGeometry(QRect(670, 400, 60, 60));
        pushButton_14->setStyleSheet(QString::fromUtf8("background-color: rgb(189, 251, 193);"));
        pushButton_15 = new QPushButton(centralwidget);
        pushButton_15->setObjectName("pushButton_15");
        pushButton_15->setGeometry(QRect(670, 460, 60, 60));
        pushButton_15->setStyleSheet(QString::fromUtf8("background-color: rgb(253, 93, 93);"));
        pushButton_16 = new QPushButton(centralwidget);
        pushButton_16->setObjectName("pushButton_16");
        pushButton_16->setGeometry(QRect(670, 520, 60, 60));
        pushButton_17 = new QPushButton(centralwidget);
        pushButton_17->setObjectName("pushButton_17");
        pushButton_17->setGeometry(QRect(610, 520, 60, 60));
        pushButton_17->setStyleSheet(QString::fromUtf8("background-color: rgb(180, 150, 214);"));
        pushButton_18 = new QPushButton(centralwidget);
        pushButton_18->setObjectName("pushButton_18");
        pushButton_18->setGeometry(QRect(550, 520, 60, 60));
        pushButton_18->setStyleSheet(QString::fromUtf8("background-color: rgb(221, 160, 139);"));
        pushButton_19 = new QPushButton(centralwidget);
        pushButton_19->setObjectName("pushButton_19");
        pushButton_19->setGeometry(QRect(490, 520, 60, 60));
        pushButton_19->setStyleSheet(QString::fromUtf8("background-color: rgb(10, 10, 10);\n"
"color: rgb(255, 255, 255);"));
        pushButton_20 = new QPushButton(centralwidget);
        pushButton_20->setObjectName("pushButton_20");
        pushButton_20->setGeometry(QRect(430, 520, 60, 60));
        pushButton_20->setStyleSheet(QString::fromUtf8("background-color: rgb(189, 251, 193);"));
        pushButton_21 = new QPushButton(centralwidget);
        pushButton_21->setObjectName("pushButton_21");
        pushButton_21->setGeometry(QRect(370, 520, 60, 60));
        pushButton_21->setStyleSheet(QString::fromUtf8("background-color: rgb(88, 217, 9);"));
        pushButton_22 = new QPushButton(centralwidget);
        pushButton_22->setObjectName("pushButton_22");
        pushButton_22->setGeometry(QRect(310, 520, 60, 60));
        pushButton_22->setStyleSheet(QString::fromUtf8("background-color: rgb(221, 160, 139);"));
        pushButton_23 = new QPushButton(centralwidget);
        pushButton_23->setObjectName("pushButton_23");
        pushButton_23->setGeometry(QRect(250, 520, 60, 60));
        pushButton_23->setStyleSheet(QString::fromUtf8("background-color: rgb(253, 93, 93);"));
        pushButton_24 = new QPushButton(centralwidget);
        pushButton_24->setObjectName("pushButton_24");
        pushButton_24->setGeometry(QRect(190, 520, 60, 60));
        pushButton_25 = new QPushButton(centralwidget);
        pushButton_25->setObjectName("pushButton_25");
        pushButton_25->setGeometry(QRect(190, 460, 60, 60));
        pushButton_25->setStyleSheet(QString::fromUtf8("background-color: rgb(253, 93, 93);\n"
""));
        pushButton_26 = new QPushButton(centralwidget);
        pushButton_26->setObjectName("pushButton_26");
        pushButton_26->setGeometry(QRect(190, 400, 60, 60));
        pushButton_26->setStyleSheet(QString::fromUtf8("background-color: rgb(180, 150, 214);"));
        pushButton_27 = new QPushButton(centralwidget);
        pushButton_27->setObjectName("pushButton_27");
        pushButton_27->setGeometry(QRect(190, 340, 60, 60));
        pushButton_27->setStyleSheet(QString::fromUtf8("background-color: rgb(221, 160, 139);"));
        pushButton_28 = new QPushButton(centralwidget);
        pushButton_28->setObjectName("pushButton_28");
        pushButton_28->setGeometry(QRect(190, 280, 60, 60));
        pushButton_28->setStyleSheet(QString::fromUtf8("background-color: rgb(253, 93, 93);"));
        pushButton_29 = new QPushButton(centralwidget);
        pushButton_29->setObjectName("pushButton_29");
        pushButton_29->setGeometry(QRect(190, 220, 60, 60));
        pushButton_29->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 0);"));
        pushButton_30 = new QPushButton(centralwidget);
        pushButton_30->setObjectName("pushButton_30");
        pushButton_30->setGeometry(QRect(190, 160, 60, 60));
        pushButton_30->setStyleSheet(QString::fromUtf8("background-color: rgb(180, 150, 214);"));
        pushButton_31 = new QPushButton(centralwidget);
        pushButton_31->setObjectName("pushButton_31");
        pushButton_31->setGeometry(QRect(190, 100, 60, 60));
        pushButton_31->setStyleSheet(QString::fromUtf8("background-color: rgb(180, 150, 214);"));
        pushButton_00 = new QPushButton(centralwidget);
        pushButton_00->setObjectName("pushButton_00");
        pushButton_00->setGeometry(QRect(190, 40, 60, 60));
        pushButton_00->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_0 = new QLabel(centralwidget);
        label_0->setObjectName("label_0");
        label_0->setGeometry(QRect(30, 30, 125, 90));
        label_0->setStyleSheet(QString::fromUtf8("font: 11pt \"Viner Hand ITC\";"));
        label_1 = new QLabel(centralwidget);
        label_1->setObjectName("label_1");
        label_1->setGeometry(QRect(30, 160, 125, 90));
        label_1->setStyleSheet(QString::fromUtf8("font: 11pt \"Viner Hand ITC\";"));
        Return = new QPushButton(centralwidget);
        Return->setObjectName("Return");
        Return->setGeometry(QRect(1110, 10, 71, 61));
        Return->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe Print\";"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(60, 420, 61, 61));
        widget = new QWidget(centralwidget);
        widget->setObjectName("widget");
        widget->setGeometry(QRect(830, 210, 261, 231));
        label = new QLabel(widget);
        label->setObjectName("label");
        label->setGeometry(QRect(10, 20, 231, 41));
        choice1 = new QPushButton(widget);
        choice1->setObjectName("choice1");
        choice1->setGeometry(QRect(0, 140, 60, 60));
        choice2 = new QPushButton(widget);
        choice2->setObjectName("choice2");
        choice2->setGeometry(QRect(90, 140, 60, 60));
        choice3 = new QPushButton(widget);
        choice3->setObjectName("choice3");
        choice3->setGeometry(QRect(180, 140, 60, 60));
        label_detail = new QLabel(widget);
        label_detail->setObjectName("label_detail");
        label_detail->setGeometry(QRect(10, 70, 231, 50));
        player__1 = new QPushButton(centralwidget);
        player__1->setObjectName("player__1");
        player__1->setGeometry(QRect(80, 290, 30, 30));
        player__2 = new QPushButton(centralwidget);
        player__2->setObjectName("player__2");
        player__2->setGeometry(QRect(80, 320, 30, 30));
        Game->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Game);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1200, 25));
        Game->setMenuBar(menubar);
        statusbar = new QStatusBar(Game);
        statusbar->setObjectName("statusbar");
        Game->setStatusBar(statusbar);

        retranslateUi(Game);

        QMetaObject::connectSlotsByName(Game);
    } // setupUi

    void retranslateUi(QMainWindow *Game)
    {
        Game->setWindowTitle(QCoreApplication::translate("Game", "MainWindow", nullptr));
        pushButton_01->setText(QCoreApplication::translate("Game", "\351\202\261\345\276\267\346\213\224", nullptr));
        pushButton_02->setText(QCoreApplication::translate("Game", "\344\272\224\345\233\233\346\223\215\345\234\272", nullptr));
        pushButton_03->setText(QCoreApplication::translate("Game", "\346\240\241\350\275\246", nullptr));
        pushButton_04->setText(QCoreApplication::translate("Game", "\344\270\200\344\275\223", nullptr));
        pushButton_05->setText(QCoreApplication::translate("Game", "\350\256\241\347\256\227\344\270\255\345\277\203", nullptr));
        pushButton_06->setText(QCoreApplication::translate("Game", "\346\234\272\344\274\232", nullptr));
        pushButton_07->setText(QCoreApplication::translate("Game", "\345\256\277\350\210\215\346\245\274", nullptr));
        pushButton_08->setText(QCoreApplication::translate("Game", "\344\272\244\346\230\223", nullptr));
        pushButton_09->setText(QCoreApplication::translate("Game", "\346\263\212\346\230\237\345\234\260", nullptr));
        pushButton_10->setText(QCoreApplication::translate("Game", "\346\240\241\350\275\246", nullptr));
        pushButton_11->setText(QCoreApplication::translate("Game", "\350\200\203\345\234\272", nullptr));
        pushButton_12->setText(QCoreApplication::translate("Game", "\344\272\214\344\275\223", nullptr));
        pushButton_13->setText(QCoreApplication::translate("Game", "\345\221\275\350\277\220", nullptr));
        pushButton_14->setText(QCoreApplication::translate("Game", "3W", nullptr));
        pushButton_15->setText(QCoreApplication::translate("Game", "\345\206\234\345\233\255", nullptr));
        pushButton_16->setText(QCoreApplication::translate("Game", "\346\214\221\346\210\230", nullptr));
        pushButton_17->setText(QCoreApplication::translate("Game", "\347\231\276\350\256\262", nullptr));
        pushButton_18->setText(QCoreApplication::translate("Game", "\347\220\206\346\225\231", nullptr));
        pushButton_19->setText(QCoreApplication::translate("Game", "\350\200\203\345\234\272", nullptr));
        pushButton_20->setText(QCoreApplication::translate("Game", "\351\272\246\351\232\206", nullptr));
        pushButton_21->setText(QCoreApplication::translate("Game", "\344\272\244\346\230\223", nullptr));
        pushButton_22->setText(QCoreApplication::translate("Game", "\344\272\214\346\225\231", nullptr));
        pushButton_23->setText(QCoreApplication::translate("Game", "\345\213\272\345\233\255", nullptr));
        pushButton_24->setText(QCoreApplication::translate("Game", "\351\223\266\350\241\214", nullptr));
        pushButton_25->setText(QCoreApplication::translate("Game", "\345\256\266\345\233\255", nullptr));
        pushButton_26->setText(QCoreApplication::translate("Game", "\345\233\276\344\271\246\351\246\206", nullptr));
        pushButton_27->setText(QCoreApplication::translate("Game", "\344\270\211\346\225\231", nullptr));
        pushButton_28->setText(QCoreApplication::translate("Game", "\347\207\225\345\215\227", nullptr));
        pushButton_29->setText(QCoreApplication::translate("Game", "\346\240\241\350\275\246", nullptr));
        pushButton_30->setText(QCoreApplication::translate("Game", "\346\234\252\345\220\215\346\271\226", nullptr));
        pushButton_31->setText(QCoreApplication::translate("Game", "\345\215\232\351\233\205\345\241\224", nullptr));
        pushButton_00->setText(QCoreApplication::translate("Game", "\350\265\267\347\202\271", nullptr));
        label_0->setText(QCoreApplication::translate("Game", "TextLabel", nullptr));
        label_1->setText(QCoreApplication::translate("Game", "TextLabel", nullptr));
        Return->setText(QCoreApplication::translate("Game", "Return", nullptr));
        pushButton->setText(QCoreApplication::translate("Game", "\346\216\267\351\252\260\345\255\220", nullptr));
        label->setText(QCoreApplication::translate("Game", "\344\272\213\344\273\266\350\257\264\346\230\216", nullptr));
        choice1->setText(QCoreApplication::translate("Game", "choice1", nullptr));
        choice2->setText(QCoreApplication::translate("Game", "PushButton", nullptr));
        choice3->setText(QCoreApplication::translate("Game", "PushButton", nullptr));
        label_detail->setText(QCoreApplication::translate("Game", "\350\277\233\344\270\200\346\255\245\350\257\264\346\230\216", nullptr));
        player__1->setText(QString());
        player__2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Game: public Ui_Game {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GAME_H
