/********************************************************************************
** Form generated from reading UI file 'sell.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SELL_H
#define UI_SELL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Sell
{
public:
    QWidget *centralwidget;
    QListWidget *listWidget;
    QLabel *label;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Sell)
    {
        if (Sell->objectName().isEmpty())
            Sell->setObjectName("Sell");
        Sell->resize(800, 600);
        centralwidget = new QWidget(Sell);
        centralwidget->setObjectName("centralwidget");
        listWidget = new QListWidget(centralwidget);
        listWidget->setObjectName("listWidget");
        listWidget->setGeometry(QRect(10, 20, 291, 551));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(480, 150, 181, 111));
        label->setStyleSheet(QString::fromUtf8("font: 16pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(480, 270, 111, 91));
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(730, 10, 61, 61));
        pushButton_2->setStyleSheet(QString::fromUtf8("font: 700 9pt \"Segoe Print\";"));
        Sell->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Sell);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 800, 25));
        Sell->setMenuBar(menubar);
        statusbar = new QStatusBar(Sell);
        statusbar->setObjectName("statusbar");
        Sell->setStatusBar(statusbar);

        retranslateUi(Sell);

        QMetaObject::connectSlotsByName(Sell);
    } // setupUi

    void retranslateUi(QMainWindow *Sell)
    {
        Sell->setWindowTitle(QCoreApplication::translate("Sell", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("Sell", "TextLabel", nullptr));
        pushButton->setText(QCoreApplication::translate("Sell", "\345\215\225\345\207\273\346\237\245\347\234\213\344\273\267\346\240\274\n"
"\345\217\214\345\207\273\345\207\272\345\224\256", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Sell", "Return", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Sell: public Ui_Sell {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SELL_H
