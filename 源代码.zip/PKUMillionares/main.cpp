#include "BaseClass.h"
#include <QApplication>
MainWindow* BaseClass::w=NULL;
Hello* BaseClass::HELLO=NULL;
StartMenu* BaseClass::STARTMENU=NULL;
Game* BaseClass::GAME=NULL;
Sell* BaseClass::SELL=NULL;
Result* BaseClass::RESULT=NULL;
MineSweepingGame* BaseClass::MINESWEEPINGGAME=NULL;
NumberBomb* BaseClass::NUMBERBOMB=NULL;
//Nogo* BaseClass::NOGO=NULL;
std::map<int,QMainWindow*> BaseClass::WINDOWS=std::map<int,QMainWindow*>();
std::default_random_engine Random_Engine(clock());
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow W;
    Hello h;
    StartMenu S;
    Game G;
    Sell SE;
    Result R;
    MineSweepingGame M;
    //Nogo N;
    NumberBomb NUM;
    BaseClass::w=&W;
    BaseClass::HELLO=&h;
    BaseClass::STARTMENU=&S;
    BaseClass::GAME=&G;
    BaseClass::SELL=&SE;
    BaseClass::RESULT=&R;
    BaseClass::MINESWEEPINGGAME=&M;
    //BaseClass::NOGO=&N;
    BaseClass::NUMBERBOMB=&NUM;
    BaseClass::init_WINDOWS();
    W.show();
    //NUM.show();
    return a.exec();
}
