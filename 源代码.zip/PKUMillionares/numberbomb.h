#ifndef NUMBERBOMB_H
#define NUMBERBOMB_H

#include <QMainWindow>
#include <random>
#include<ctime>
#include<queue>
#include <QRandomGenerator>
namespace Ui {
class NumberBomb;
}
using namespace std;
extern default_random_engine Random_Engine;
class NumberBombClass{
public:
    clock_t time_start;
    int time_limit=5;
    int left_num;
    int goal_num;
    void init(){
        time_start=clock();goal_num=Random_Engine()%1000;
        left_num=8;
    }
    int check(int num){
        return num-goal_num;
    }
    bool time_exceed(){
        return time_limit*CLOCKS_PER_SEC>(clock()-time_start);
    }
    int time_left(){
        if(time_exceed())return (clock()-time_start)/CLOCKS_PER_SEC;
        else return -1;
    }
};

class NumberBomb : public QMainWindow
{
    Q_OBJECT

public:
    explicit NumberBomb(QWidget *parent = nullptr);
    ~NumberBomb();


protected:
    void paintEvent(QPaintEvent* e) override;
    void renew();
private slots:
    void on_lineEdit_returnPressed();

    void on_pushButton_clicked();

private:
    Ui::NumberBomb *ui;
};

#endif // NUMBERBOMB_H
