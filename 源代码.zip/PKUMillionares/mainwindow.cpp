#include "BaseClass.h"
#include "./ui_mainwindow.h"
#include "QMouseEvent"
BubbleTipsWidget* tipps[100];
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);tipps[1]=0;
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::paintEvent(QPaintEvent *e){
    QPainter painter(this);
    QPixmap pic;
    pic.load("Resource/frontpage.jpg");
    painter.drawPixmap(ui->centralwidget->pos().x(),ui->centralwidget->pos().y(),ui->centralwidget->width(),ui->centralwidget->height(),pic);

}

void MainWindow::on_pushButton_clicked()
{
    BaseClass::Logic(1,0);
}
void MainWindow::mousePressEvent(QMouseEvent* e){}




