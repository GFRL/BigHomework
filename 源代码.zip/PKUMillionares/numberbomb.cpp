#include "numberbomb.h"
#include "BaseClass.h"
#include "ui_numberbomb.h"
#include <ctime>
#include<QTimer>
bool init_need=true;
NumberBombClass AA;
int result=0;
bool actives=false;
int numberbomb_mode;
int pre_mode=1000;
NumberBomb::NumberBomb(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::NumberBomb)
{
    ui->setupUi(this);
    QTimer *timer=new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(repaint()));
    timer->start(500);
    init_need=true;numberbomb_mode=0;
}
void NumberBomb::paintEvent(QPaintEvent* e){
    QPainter painter(this);
    QPixmap pic;
    pic.load("Resource/number.jpg");
    painter.drawPixmap(ui->centralwidget->pos().x(),ui->centralwidget->pos().y(),ui->centralwidget->width(),ui->centralwidget->height(),pic);
    if(init_need)AA.init(),init_need=false,numberbomb_mode=0,result=0,
            actives=true,ui->time_lcd->display(AA.time_limit),pre_mode=1000,ui->pushButton->hide();
    if(numberbomb_mode==0||numberbomb_mode==3||numberbomb_mode==4){
        int s=AA.time_left();
        if(s==-1){
            numberbomb_mode=1;result=-1;return;
        }
        if(AA.left_num<=0){
            numberbomb_mode=2;result=-1;return;
        }
        ui->num_lcd->display(AA.left_num);
        ui->lineEdit->show();ui->result_return->hide();
        ui->time_lcd->display(s);
        if(numberbomb_mode==3){
            ui->result_return->setText("太大了");
            ui->lineEdit->show();ui->result_return->show();ui->pushButton->hide();
        }
        else if(numberbomb_mode==4){
            ui->result_return->setText("太小了");
            ui->lineEdit->show();ui->result_return->show();ui->pushButton->hide();
        }
    }
    else if(numberbomb_mode==1){
        ui->result_return->setText("您已经超时!你输了!");
        ui->result_return->show();ui->lineEdit->hide();ui->pushButton->show();
    }
    else if(numberbomb_mode==2){
        ui->result_return->setText("您的次数用完了,你输了!");
        ui->result_return->show();ui->lineEdit->hide();ui->pushButton->show();
    }
    else if(numberbomb_mode==5){
        ui->result_return->setText("刚刚好,你赢了");
        ui->result_return->show();ui->lineEdit->hide();ui->pushButton->show();
    }
    else if(numberbomb_mode==6){
        ui->result_return->setText("输入不合法(请保证在0-10000之间）");
        ui->lineEdit->show();ui->result_return->show();ui->pushButton->hide();
    }

}
NumberBomb::~NumberBomb()
{
    delete ui;
}

void NumberBomb::on_lineEdit_returnPressed()
{
    if(result!=0||AA.left_num<=0)return;
    QString ss=ui->lineEdit->text();
    if(ss.length()>4){numberbomb_mode=6;repaint();return;}
    else{
        for(int i=ss.length()-1;i>=0;i--){
            if(ss[i]>'9'||ss[i]<'0'){numberbomb_mode=6;repaint();return;}
        }
    }
    int valdiation=AA.check(ss.toInt());qDebug()<<"valdiation "<<valdiation;
    AA.left_num--;ui->num_lcd->display(AA.left_num);AA.time_start=clock();
    if(valdiation==0){numberbomb_mode=5;repaint();return;}
    else if(valdiation>0){numberbomb_mode=3;repaint();return;}
    else {numberbomb_mode=4;repaint();return;}
}


void NumberBomb::on_pushButton_clicked()
{
    init_need=true;
    if(numberbomb_mode==5)
    Now_player.MAP.users[Now_player.MAP.now_user].add_money(1000);
    actives=false;
    BaseClass::Logic(3,8);
}
void NumberBomb::renew(){
    int s=AA.time_left();
    if(s==-1){
        numberbomb_mode=1;result=-1;repaint();return;
    }
    ui->time_lcd->display(s);
}
